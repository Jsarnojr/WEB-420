// database/collections.js
const books = require('./books'); // Ensure this path is correct

module.exports = {
    books
};
