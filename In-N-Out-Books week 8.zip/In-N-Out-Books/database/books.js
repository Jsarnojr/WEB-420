// database/books.js

// Mock book data
const booksDB = [
    { id: 1, title: 'Book 1', author: 'Author 1' },
    { id: 2, title: 'Book 2', author: 'Author 2' },
  ];
  
  module.exports = booksDB;
  